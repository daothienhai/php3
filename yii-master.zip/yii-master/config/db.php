<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=fpoly_php3_assignment',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
